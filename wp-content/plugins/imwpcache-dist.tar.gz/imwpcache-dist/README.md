## imwpcache ##
最快的wordpress缓存插件，支持文件缓存，Memcache缓存，Redis缓存

## 更新记录 ##

v1.2.0
增加sqlite驱动，支持sqlite存储缓存数据

v1.0.1
增加memcached驱动
增加页面自定义增加不缓存标记功能

v1.0.0
初始版本，速度极快的wordpress缓存插件 