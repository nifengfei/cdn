<?php
require_once dirname(__DIR__) . '/classes/imwpcache.php'; new imwpcache\classes\imwpcache();