<?php
 namespace imwpf\modules\logger; class Exception extends \Exception { } 