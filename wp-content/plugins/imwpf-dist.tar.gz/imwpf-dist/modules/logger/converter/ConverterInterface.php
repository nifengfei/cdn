<?php
 namespace imwpf\modules\logger\converter; interface ConverterInterface { public function convert($data); } 