<?php
namespace imwpf\modules; class table { public function get($data) { } } 